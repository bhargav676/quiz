import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation, Link } from 'react-router-dom';
import { useLoginMutation, useAppDispatch, useAppSelector } from '../store';
import { setCredentials } from '../store/authSlice';
import styles from './Login.module.scss';
import { Role } from '../types';

const Login: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  const [login, { isLoading }] = useLoginMutation();
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const location = useLocation();
  const isAuthenticated = useAppSelector((state) => state.auth.isAuthenticated);

  // Redirect to original location or appropriate dashboard if already authenticated
  const { user } = useAppSelector((state) => state.auth);
  const getDashboardPath = () => {
    if (!user) return '/login';
    if (user.role === Role.ADMIN) return '/admin/dashboard';
    if (user.role === Role.INSTRUCTOR) return '/instructor/dashboard';
    if (user.role === Role.PARTICIPANT) return '/participant/dashboard';
    return '/login';
  };
  const from = (location.state as any)?.from?.pathname || getDashboardPath();

  useEffect(() => {
    if (isAuthenticated) {
      navigate(from, { replace: true });
    }
  }, [isAuthenticated, navigate, from]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!email || !password) {
      setErrorMsg('Please enter both email and password.');
      return;
    }

    try {
      const res = await login({ email, password }).unwrap();
      
      // Ensure the response returned the user
      if (res.success && res.data) {
        const { user: loggedInUser, accessToken } = res.data;
        
        // Ensure user is Admin, Instructor or Participant
        if (
          loggedInUser.role !== Role.ADMIN &&
          loggedInUser.role !== Role.INSTRUCTOR &&
          loggedInUser.role !== Role.PARTICIPANT
        ) {
          setErrorMsg('Access denied: You are not authorized to view the portal.');
          return;
        }

        dispatch(setCredentials({ user: loggedInUser, accessToken }));
        
        const targetPath = (location.state as any)?.from?.pathname || 
          (loggedInUser.role === Role.ADMIN 
            ? '/admin/dashboard' 
            : loggedInUser.role === Role.INSTRUCTOR 
              ? '/instructor/dashboard' 
              : '/participant/dashboard');

        navigate(targetPath, { replace: true });
      } else {
        setErrorMsg(res.message || 'Login failed. Please check your credentials.');
      }
    } catch (err: any) {
      setErrorMsg(
        err?.data?.message || err?.message || 'Invalid email or password. Please try again.'
      );
    }
  };

  return (
    <div className={styles.loginContainer}>
      <div className={`${styles.blurBg} ${styles.primary}`}></div>
      <div className={`${styles.blurBg} ${styles.accent}`}></div>

      <div className={styles.loginCard}>
        <div className={styles.header}>
          <h1>QuizArena</h1>
          <p>Admin Assessment Portal</p>
        </div>

        <form className={styles.form} onSubmit={handleSubmit}>
          {errorMsg && (
            <div className={styles.errorAlert}>
              <span>⚠️</span>
              <span>{errorMsg}</span>
            </div>
          )}

          <div className={styles.inputGroup}>
            <label htmlFor="email">Email Address</label>
            <input
              id="email"
              type="email"
              placeholder="admin@quizarena.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              disabled={isLoading}
              required
            />
          </div>

          <div className={styles.inputGroup}>
            <label htmlFor="password">Password</label>
            <input
              id="password"
              type="password"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              disabled={isLoading}
              required
            />
          </div>

          <button type="submit" className={styles.submitBtn} disabled={isLoading}>
            {isLoading ? (
              <>
                <div className={styles.spinner}></div>
                Signing In...
              </>
            ) : (
              'Sign In'
            )}
          </button>
        </form>

        <div className={styles.footerText}>
          Don't have an account? <Link to="/register">Sign Up</Link>
        </div>
      </div>
    </div>
  );
};

export default Login;
