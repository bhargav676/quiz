import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useRegisterMutation, useAppDispatch, useAppSelector } from '../store';
import { setCredentials } from '../store/authSlice';
import styles from './Register.module.scss';
import { Role } from '../types';

const Register: React.FC = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  const [register, { isLoading }] = useRegisterMutation();
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const isAuthenticated = useAppSelector((state) => state.auth.isAuthenticated);
  const user = useAppSelector((state) => state.auth.user);

  useEffect(() => {
    if (isAuthenticated && user) {
      if (user.role === Role.PARTICIPANT) {
        navigate('/participant/dashboard', { replace: true });
      } else if (user.role === Role.ADMIN) {
        navigate('/admin/dashboard', { replace: true });
      } else if (user.role === Role.INSTRUCTOR) {
        navigate('/instructor/dashboard', { replace: true });
      }
    }
  }, [isAuthenticated, user, navigate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!name.trim() || !email.trim() || !password || !confirmPassword) {
      setErrorMsg('All fields are required.');
      return;
    }

    if (name.trim().length < 2) {
      setErrorMsg('Name must be at least 2 characters long.');
      return;
    }

    if (password.length < 6) {
      setErrorMsg('Password must be at least 6 characters long.');
      return;
    }

    if (password !== confirmPassword) {
      setErrorMsg('Passwords do not match.');
      return;
    }

    try {
      const res = await register({
        name: name.trim(),
        email: email.trim().toLowerCase(),
        password,
        role: Role.PARTICIPANT,
      }).unwrap();

      if (res.success && res.data) {
        const { user: newUser, accessToken } = res.data;
        dispatch(setCredentials({ user: newUser, accessToken }));
        navigate('/participant/dashboard', { replace: true });
      } else {
        setErrorMsg(res.message || 'Registration failed.');
      }
    } catch (err: any) {
      setErrorMsg(
        err?.data?.message || err?.message || 'Email already exists or invalid data. Please try again.'
      );
    }
  };

  return (
    <div className={styles.registerContainer}>
      <div className={`${styles.blurBg} ${styles.primary}`}></div>
      <div className={`${styles.blurBg} ${styles.accent}`}></div>

      <div className={styles.registerCard}>
        <div className={styles.header}>
          <h1>Create Account</h1>
          <p>Sign up to start taking MCQs quizzes</p>
        </div>

        <form onSubmit={handleSubmit} className={styles.form}>
          {errorMsg && (
            <div className={styles.errorAlert}>
              <span>⚠️</span>
              <span>{errorMsg}</span>
            </div>
          )}

          <div className={styles.inputGroup}>
            <label htmlFor="name">Full Name</label>
            <input
              id="name"
              type="text"
              placeholder="e.g. John Doe"
              value={name}
              onChange={(e) => setName(e.target.value)}
              disabled={isLoading}
              required
            />
          </div>

          <div className={styles.inputGroup}>
            <label htmlFor="email">Email Address</label>
            <input
              id="email"
              type="email"
              placeholder="e.g. john@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              disabled={isLoading}
              required
            />
          </div>

          <div className={styles.inputGroup}>
            <label htmlFor="password">Password</label>
            <input
              id="password"
              type="password"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              disabled={isLoading}
              required
            />
          </div>

          <div className={styles.inputGroup}>
            <label htmlFor="confirmPassword">Confirm Password</label>
            <input
              id="confirmPassword"
              type="password"
              placeholder="••••••••"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              disabled={isLoading}
              required
            />
          </div>

          <button type="submit" className={styles.submitBtn} disabled={isLoading}>
            {isLoading ? (
              <>
                <div className={styles.spinner}></div>
                Signing Up...
              </>
            ) : (
              'Sign Up'
            )}
          </button>
        </form>

        <div className={styles.footerText}>
          Already have an account? <Link to="/login">Sign In</Link>
        </div>
      </div>
    </div>
  );
};

export default Register;
